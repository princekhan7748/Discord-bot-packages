<div align="center">
  <p>
    <h1>Discord.JS v13 Tutorials</h1>
  </p>
</div>


```
Official Repository of Discord.JS v13 Tutorials by FiredragonPlayz on YouTube!
```
## How am I suppose to get the Code for each video?

- First, You'll have to click on button called "Branches"

 ![](https://media.discordapp.net/attachments/821972674380038166/872511591529209856/unknown.png)


- Then, the list of branches will show up for each video.

![](https://media.discordapp.net/attachments/821972674380038166/872513016187465788/unknown.png)

- Then Click on the branch that you need the code of!
## Join For Support

<br>
</br>
<a href=""><img src="https://invidget.switchblade.xyz/FCP2HWksBU"/></a>
<br></br>
<div align="center">
<a href="https://discord.gg/FCP2HWksBU">
    <img src="https://user-images.githubusercontent.com/59381835/92191514-d649ad80-ee18-11ea-9bc4-e95c7a122a99.png" alt="Discord" width="80"/>
  </a>
  <a href="https://youtube.com/FiredragonPlayz">
    <img src="https://user-images.githubusercontent.com/59381835/92191346-676c5480-ee18-11ea-8240-e416eb1a5b5d.png" alt="Discord" width="80"/>
  </a>
  </div>
